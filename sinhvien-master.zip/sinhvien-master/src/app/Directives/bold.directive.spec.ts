import { BoldDirective } from './bold.directive';

describe('BoldDirective', () => {
  it('should create an instance', () => {
    // const directive = new BoldDirective();
    // expect(directive).toBeTruthy();
  });
});
